package com.fusion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
