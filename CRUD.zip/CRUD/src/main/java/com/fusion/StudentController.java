package com.fusion;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	
	
	public StudentController() {
		System.out.println("Inside Student Controller");	
	}
	

	@RequestMapping("/login")
   public String StudentMapping() {
	return "Hello_Developer";
		
	}

}
